//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by toolbar.rc
//
#define IDD_ABOUTBOX                    100
#define IDC_CBWIDTH                     101
#define IDR_MAINFRAME                   128
#define IDR_TOOLBATYPE                  129
#define IDR_CONTEXTMENU                 130
#define IDR_TBCOLOR                     131
#define ID_COLOR_BLACK                  32771
#define ID_COLOR_BLUE                   32772
#define ID_COLOR_GREEN                  32773
#define ID_COLOR_CYAN                   32774
#define ID_COLOR_RED                    32775
#define ID_COLOR_MAGENTA                32776
#define ID_COLOR_YELLOW                 32777
#define ID_COLOR_WHITE                  32778
#define ID_WIDTH_VTHIN                  32779
#define ID_WIDTH_THIN                   32780
#define ID_WIDTH_MEDIUM                 32781
#define ID_WIDTH_THICK                  32782
#define ID_WIDTH_VTHICK                 32783
#define ID_VIEW_COLORBAR                32812
#define ID_BUTTON32813                  32813
#define IDS_WIDTH_THIN                  61447
#define IDS_WIDTH_MEDIUM                61448
#define IDS_WIDTH_THICK                 61449
#define IDS_WIDTH_VTHICK                61450
#define IDS_WIDTH_VTHIN                 61451
#define ID_INDICATOR_COLOR              61452
#define ID_INDICATOR_WIDTH              61453

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        137
#define _APS_NEXT_COMMAND_VALUE         32818
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
